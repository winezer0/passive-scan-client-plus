package burp;

import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;

import javax.net.ssl.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Proxy.Type;
import java.net.URL;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.*;

//https://blog.csdn.net/sbc1232123321/article/details/79334130
public class HttpAndHttpsProxy {
    public static Map<String,String> Proxy(IHttpRequestResponse requestResponse, Set hashSet){  //新增
        byte[] req = requestResponse.getRequest();
        String url = null;
        byte[] reqbody = null;
        List<String> headers = null;

        IHttpService httpService = requestResponse.getHttpService();
        IRequestInfo reqInfo = BurpExtender.helpers.analyzeRequest(httpService,req);

        String body = null;
        if(reqInfo.getMethod().equals("POST")){
            int bodyOffset = reqInfo.getBodyOffset();
            try {
                body = new String(req, bodyOffset, req.length - bodyOffset, "UTF-8");
                reqbody = body.getBytes("UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        
/*
        BurpExtender.stdout.println("[******************临时调试开始******************]"); //新增
        BurpExtender.stdout.println("getMethod()---"+reqInfo.getMethod()); //新增
        BurpExtender.stdout.println("getContentType()---"+reqInfo.getContentType()); //新增
        BurpExtender.stdout.println("getUrl().toString()---"+reqInfo.getUrl().toString()); //新增
        //BurpExtender.stdout.println("getHeaders()---"+reqInfo.getHeaders()); //新增
        //BurpExtender.stdout.println("getParameters()---"+reqInfo.getParameters()); //新增
        BurpExtender.stdout.println("body-------"+body); //新增
        //BurpExtender.stdout.println("reqbody---"+reqbody); //新增
        BurpExtender.stdout.println("[******************临时调试结束******************]"); //新增
*/
        
        //BurpExtender.stderr.println("[+] 请求url: " + resInfo.getUrl());
        headers = reqInfo.getHeaders();
        url = reqInfo.getUrl().toString();
        BurpExtender.stdout.println("[******************开始处理******************]"); //新增
        String url_body = url+ "&"+ body;
        BurpExtender.stdout.println("[+] 请求url+body:"+ url_body);//新增 输出url+内容
        if(BurpExtender.hashSet.contains(url_body)){
            BurpExtender.stdout.println("[-] url内容已经重复,不再重复处理" );             // 如果有了url,这个集合里面有包含了这个url，说明这个url是重复的，就返回null
            BurpExtender.stdout.println("[******************处理完毕******************]"); //新增
            return null;
        }else{
            // hashSet里面存放的都是不重复的url
            BurpExtender.hashSet.add(url_body);
            BurpExtender.stdout.println("[+] url内容没有重复，加入hashSet"); //新增 输出url+内容
            //BurpExtender.stdout.println("当前hashSet内容:"+BurpExtender.hashSet);//新增 输出hashSet内容
        }

        if(httpService.getProtocol().equals("https")){

            return HttpsProxy( hashSet,url_body,url, headers, reqbody, Config.PROXY_HOST, Config.PROXY_PORT,Config.PROXY_USERNAME,Config.PROXY_PASSWORD);
        }else {

            return HttpProxy( hashSet,url_body,url, headers, reqbody, Config.PROXY_HOST, Config.PROXY_PORT,Config.PROXY_USERNAME,Config.PROXY_PASSWORD);
        }
    }
    
    
    
//--------------------------HttpsProxy--------------------------------//
    public static Map<String,String> HttpsProxy(Set hashSet,String url_body, String url, List<String> headers,byte[] body, String proxy, int port,String username,String password){
        Map<String,String> mapResult = new HashMap<String,String>();
        String status = "";
        String rspHeader = "";
        String result = "";

        HttpsURLConnection httpsConn = null;
        PrintWriter out = null;
        BufferedReader in = null;

        BufferedReader reader = null;

        try {

            URL urlClient = new URL(url);
            SSLContext sc = SSLContext.getInstance("SSL");
            // 指定信任https
            sc.init(null, new TrustManager[] { new TrustAnyTrustManager() }, new java.security.SecureRandom());
            //创建代理虽然是https也是Type.HTTP
            Proxy proxy1=new Proxy(Type.HTTP, new InetSocketAddress(proxy, port));
            //设置代理
            httpsConn = (HttpsURLConnection) urlClient.openConnection(proxy1);

            //设置账号密码
            if(username != null && username != "" && password != null && password != "" ) {
                String user_pass = String.format("%s:%s", username, password);
                String headerKey = "Proxy-Authorization";
                String headerValue = "Basic " + Base64.encode(user_pass.getBytes());
                httpsConn.setRequestProperty(headerKey, headerValue);
            }
            

            httpsConn.setSSLSocketFactory(sc.getSocketFactory());
            httpsConn.setHostnameVerifier(new TrustAnyHostnameVerifier());
            // 设置通用的请求属性
            for(String header:headers){
                if(header.startsWith("GET") ||
                        header.startsWith("POST") ||
                        header.startsWith("PUT")){
                    continue;
                }
                String[] h = header.split(":");
                String header_key = h[0].trim();
                String header_value = h[1].trim();
                httpsConn.setRequestProperty(header_key, header_value);
            }
            
            // 发送POST请求必须设置如下两行
            httpsConn.setDoOutput(true);
            httpsConn.setDoInput(true);
            
            // 获取URLConnection对象对应的输出流
            out = new PrintWriter(httpsConn.getOutputStream());
            BurpExtender.stdout.println("[*] 成功获取URLConnection对象对应的输出流"); //新增
            if(body != null) {
                // 发送请求参数
                out.print(new String(body));
                BurpExtender.stdout.println("[*] 发送POST请求参数");
            }
            
            // flush输出流的缓冲
            out.flush();


            /*
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(httpsConn.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                BurpExtender.stdout.println("HTTPS读取数据中"); //新增
                result += line;
                result += "\r\n";
            }
            */
           
            httpsConn.disconnect(); // 断开连接
            BurpExtender.stdout.println("[*] 断开连接,输出URL响应");
            // 获取响应头
            Map<String, List<String>> mapHeaders = httpsConn.getHeaderFields();
            for (Map.Entry<String, List<String>> entry : mapHeaders.entrySet()) {
                String key = entry.getKey();
                List<String> values = entry.getValue();
                String value = "";
                for(String v:values){
                    value += v;
                }

                if(key == null) {
                    String header_line = String.format("%s\r\n",value);
                    rspHeader += header_line;
                }else{
                    String header_line = String.format("%s: %s\r\n", key, value);
                    rspHeader += header_line;
                }
            }
            BurpExtender.stdout.println("[*] 输出ResponseMessage结果_https:" + httpsConn.getResponseMessage());//新增
            status = String.valueOf(httpsConn.getResponseCode());
            Utils.updateSuccessCount();
            BurpExtender.stdout.println("[*] 输出status信息:" + status); //新增
        } catch (Exception e) {
            httpsConn.disconnect(); //新增 断开连接
            //e.printStackTrace();
            BurpExtender.stdout.println("[*] 输出ResponseMessage异常信息:" + e.getMessage()); //新增
            result = e.getMessage();
            Utils.updateFailCount();
            //判断是不是拒绝连接
            if ( e.getMessage().contains("Connection refused: connect") ){
	            hashSet.remove(url_body);//新增
	            BurpExtender.stdout.println("[*] 移除hashSet中的url_body" ); //新增
	            }
	      BurpExtender.stdout.println("[*] 请求处理完毕"); //新增
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
            }
            try {
                if (in != null) {
                    in.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (out != null) {
                out.close();
            }
        }
        /* 这句话似乎是重复的
        try {
            status = String.valueOf(httpsConn.getResponseCode());
        } catch (IOException e) {
            status = e.getMessage();
            BurpExtender.stderr.println("[*] 输出getResponseCode异常信息:" + e.getMessage());
            BurpExtender.stderr.println("--------------------------------"); //新增
        }*/
        
        BurpExtender.stdout.println("[******************处理完毕******************]"); //新增
        mapResult.put("status",status);
        mapResult.put("header",rspHeader);
        mapResult.put("result",result);
        return mapResult;
    }
    
    
    
//--------------------------HttpProxy--------------------------------//
    public static Map<String,String> HttpProxy(Set hashSet, String url_body, String url,List<String> headers,byte[] body, String proxy, int port,String username,String password) {
        Map<String,String> mapResult = new HashMap<String,String>();
        String status = "";
        String rspHeader = "";
        String result = "";


        HttpURLConnection httpConn = null;
        PrintWriter out = null;
        BufferedReader in = null;
        BufferedReader reader = null;
        try {
            URL urlClient = new URL(url);
            SSLContext sc = SSLContext.getInstance("SSL");
            // 指定信任https
            sc.init(null, new TrustManager[] { new TrustAnyTrustManager() }, new java.security.SecureRandom());

            //创建代理
            Proxy proxy1=new Proxy(Type.HTTP, new InetSocketAddress(proxy, port));
            //设置代理
            httpConn = (HttpURLConnection) urlClient.openConnection(proxy1);

            //设置账号密码
            if(username != null && username != "" && password != null && password != "" ) {
                String user_pass = String.format("%s:%s", username, password);
                String headerKey = "Proxy-Authorization";
                String headerValue = "Basic " + Base64.encode(user_pass.getBytes());
                httpConn.setRequestProperty(headerKey, headerValue);
            }


            // 设置通用的请求属性
            for(String header:headers){
                if(header.startsWith("GET") ||
                        header.startsWith("POST") ||
                        header.startsWith("PUT")){
                    continue;
                }
                String[] h = header.split(":");
                String header_key = h[0].trim();
                String header_value = h[1].trim();
                //BurpExtender.stdout.println("key: " + h[0].trim());
                //BurpExtender.stdout.println("value: " + h[1].trim());
                httpConn.setRequestProperty(header_key, header_value);
            }

            // 发送POST请求必须设置如下两行
            httpConn.setDoOutput(true);
            httpConn.setDoInput(true);
            
            // 获取URLConnection对象对应的输出流
            out = new PrintWriter(httpConn.getOutputStream());
            BurpExtender.stdout.println("[*] 成功获取URLConnection对象对应的输出流"); //新增
            if(body != null) {
                // 发送请求参数
                out.print(new String(body));
                BurpExtender.stdout.println("[*] 发送POST请求参数");
            }
            // flush输出流的缓冲
            out.flush();
            /*
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(httpConn.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result += line;
                result += "\r\n";
            }
            */
            // 断开连接
            httpConn.disconnect();
            BurpExtender.stdout.println("[*] 断开连接,输出URL响应");
            Map<String, List<String>> mapHeaders = httpConn.getHeaderFields();
            for (Map.Entry<String, List<String>> entry : mapHeaders.entrySet()) {
                String key = entry.getKey();
                List<String> values = entry.getValue();
                String value = "";
                for(String v:values){
                    value += v;
                }

                if(key == null) {
                    String header_line = String.format("%s\r\n",value);
                    rspHeader += header_line;
                }else{
                    String header_line = String.format("%s: %s\r\n", key, value);
                    rspHeader += header_line;
                }
            }
            BurpExtender.stdout.println("[*] 输出ResponseMessage结果_http:" + httpConn.getResponseMessage());
            status = String.valueOf(httpConn.getResponseCode());
            Utils.updateSuccessCount();
            BurpExtender.stdout.println("[*] 输出status信息:" + status); //新增
        } catch (Exception e) {
            httpConn.disconnect(); //新增 断开连接
            //e.printStackTrace();
            BurpExtender.stdout.println("[*] 输出ResponseMessage异常" + e.getMessage()); //新增
            result = e.getMessage();
            Utils.updateFailCount();
            //判断是不是拒绝连接
            if ( e.getMessage().contains("Connection refused: connect") ){
	            hashSet.remove(url_body);//新增
	            BurpExtender.stdout.println("[*] 移除hashSet中的url_body" ); //新增
	            }
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
            }
            try {
                if (in != null) {
                    in.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (out != null) {
                out.close();
            }
        }
        /* 这句话似乎是重复的
        try {
            status = String.valueOf(httpConn.getResponseCode());
        } catch (IOException e) {
            status = e.getMessage();
            BurpExtender.stderr.println("[*] 输出getResponseCode异常信息:" + e.getMessage());
            BurpExtender.stderr.println("--------------------------------"); //新增
        }*/
        
        BurpExtender.stdout.println("[******************处理完毕******************]"); //新增
        mapResult.put("status",status);
        mapResult.put("header",rspHeader);
        mapResult.put("result",result);
        return mapResult;
    }



    private static class TrustAnyTrustManager implements X509TrustManager {

        public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        }

        public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        }

        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[] {};
        }
    }

    private static class TrustAnyHostnameVerifier implements HostnameVerifier {
        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    }
}